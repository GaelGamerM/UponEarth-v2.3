//define variables
xspd = 0;
yspd = 0;

move_spd = 2.8;

facing_direction = 2;