//control
var up_key = keyboard_check(vk_up);
var down_key = keyboard_check(vk_down);
var left_key = keyboard_check(vk_left);
var right_key = keyboard_check(vk_right);

//movement
xspd = (right_key - left_key) * move_spd;
yspd = (down_key - up_key) * move_spd;

//collisions
if (place_meeting(x + xspd, y, obj_collider)) {
	xspd = 0;
}
if (place_meeting(x, y + yspd, obj_collider)) {
	yspd = 0;
}

x += xspd;
y += yspd;

//animate
if (xspd > 0) {
	sprite_index = spr_player_main_r;
} else if (xspd < 0) {
	sprite_index = spr_player_main_l;
} else if (yspd > 0) {
	sprite_index = spr_player_main_d;
} else if (yspd < 0) {
	sprite_index = spr_player_main_u;
}

if (xspd != 0 or yspd != 0) {
	image_speed = 2;
} else {
	image_speed	= 0;
	image_index = 0;
}

//don't shake
x[0] = round(x[0.1]);
y[0] = round(y[0.1]);

//keep track of direction facing
if (sprite_index == spr_player_main_r) {
	facing_direction = 0;
}
if (sprite_index == spr_player_main_l) {
	facing_direction = 1;
}
if (sprite_index == spr_player_main_d) {
	facing_direction = 2;
}
if (sprite_index == spr_player_main_u) {
	facing_direction = 3;
}