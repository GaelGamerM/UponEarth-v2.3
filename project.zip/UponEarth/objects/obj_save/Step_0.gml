if (place_meeting(x, y, obj_player)) {
	ini_open("uponearth.ini");
	ini_write_real("save0", "room", room);
	ini_write_real("save0", "x", obj_player.x);
	ini_write_real("save0", "y", obj_player.y);
	ini_write_real("save0", "facing", obj_player.facing_direction);
	ini_close()
}