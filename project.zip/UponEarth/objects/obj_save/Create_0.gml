room_to_save = global.rm1;

//0 = rm_title
//1 = rm_waterfall
//2 = rm_papsroom