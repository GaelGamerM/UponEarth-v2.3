//variable
global.start_room = rm_waterfall;
global.start_x = 181;
global.start_y = 85;
global.start_facing = 2;

global.new_game = false;
global.title_buttons = false;

global.rm0 = rm_title;
global.rm1 = rm_waterfall;
global.rm2 = rm_papsroom;

if (file_exists("uponearth.ini")) {
	instance_create_depth(-50, 174, 100, obj_buttons_continue);
	ini_open("uponearth.ini");
	global.start_room = ini_read_real("save0", "room", rm_waterfall);
	global.start_x = ini_read_real("save0", "x", 181);
	global.start_y = ini_read_real("save0", "y", 85);
	global.start_facing = ini_read_real("save0", "facing", 2);
	ini_close();
} else {
	instance_create_depth(-50, 174, 100, obj_buttons);
}