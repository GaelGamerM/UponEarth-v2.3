if (y < 120) {
	y += 3;
}

//don't shake
x[0] = round(x[0.1]);
y[0] = round(y[0.1]);