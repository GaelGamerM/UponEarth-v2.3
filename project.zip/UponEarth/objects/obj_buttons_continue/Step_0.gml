if (x < 51.733) {
	x += 1.5;
}

//don't shake
x[0] = round(x[0.1]);
y[0] = round(y[0.1]);

//start save
ini_open("uponearth.ini");
if (image_index = 0 and (keyboard_check_pressed(ord("Z")) or keyboard_check_pressed(vk_enter))) {
	room_goto(global.start_room);
	var instantiated = instance_create_layer(global.start_x, global.start_y, "Player", obj_player);
	global.new_game = false;
}
if (image_index = 1 and (keyboard_check(ord("Z")) or keyboard_check(vk_enter))) {
	file_delete("uponearth.ini");
	game_restart();
}
if (image_index = 2 and (keyboard_check_pressed(ord("Z")) or keyboard_check_pressed(vk_enter))) {}
if (image_index = 3 and (keyboard_check_pressed(ord("Z")) or keyboard_check_pressed(vk_enter))) {
	game_end();
}
ini_close();