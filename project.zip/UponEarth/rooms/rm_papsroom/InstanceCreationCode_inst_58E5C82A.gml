room_to_save = global.rm2;

//0 = rm_title
//1 = rm_waterfall
//2 = rm_papsroom