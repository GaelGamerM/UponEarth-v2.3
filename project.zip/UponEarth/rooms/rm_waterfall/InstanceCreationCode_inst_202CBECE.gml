target_x = 220;
target_y = 200;
target_room = rm_papsroom;
facing = 3;
//0 = right
//1 = left
//2 = down
//3 = up